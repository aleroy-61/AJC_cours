package test;

import java.util.List;
import java.util.Scanner;


import dao.DAOActivite;
import dao.DAOAdmin;
import dao.DAOClient;
import dao.DAOCompte;
import dao.DAOPays;
import dao.DAOReservation;
import dao.DAOVoyage;
import dao.DAOVoyageur;
import metier.Admin;
import metier.Compte;
import metier.Pays;
import metier.Reservation;
import metier.Voyage;
import metier.Voyageur;

public class test {

	public static String saisieString(String message) 
	{
		Scanner sc = new Scanner(System.in);
		System.out.println(message);
		return sc.nextLine();
	}

	public static double saisieDouble(String message) 
	{
		Scanner sc = new Scanner(System.in);
		System.out.println(message);
		return sc.nextDouble();
	}

	public static int saisieInt(String message) 
	{
		Scanner sc = new Scanner(System.in);
		System.out.println(message);
		return sc.nextInt();
	}
	static DAOActivite daoActivite= new DAOActivite();
	static DAOAdmin daoAdmin= new DAOAdmin();
	static DAOClient daoClient= new DAOClient();
	static DAOCompte daoCompte= new DAOCompte(); 
	static DAOReservation daoReservation= new DAOReservation();
	static DAOVoyageur daoVoyageur= new DAOVoyageur(); 
	static DAOPays daoPays=new DAOPays();
	static DAOVoyage daoVoyage= new DAOVoyage(); 
	static Compte compteConnected;


	private static void menuPrincipal() {

		compteConnected = null;
		System.out.println("Welcome, merci de faire un choix :");
		System.out.println("1 - Voir les voyages ");
		System.out.println("2 - Se connecter ");
		System.out.println("3 - Cr�er un compte ");
		int choix = saisieInt("");

		switch(choix) 
		{
		case 1 : listeVoyages();break;
		case 2 : seConnecter();break;
		case 3 : creationCompte();break;
		default : System.out.println("Choix impossible !\n");
		}

		menuPrincipal();
	}

	private static void seConnecter() {
		String login=saisieString("Saisir login ");
		String password=saisieString("Saisir password ");

		compteConnected=daoCompte.checkConnect(login, password);

		if(compteConnected instanceof Admin) {
			listeVoyages();
		}

		else if(compteConnected instanceof Compte)
		{ System.out.println("Bienvenue cher Client :)");
		listeVoyages();
		}

		else { System.out.println("Identifiant invalide, veuillez cr�er un compte");
		creationCompte();
		}

	}

	private static void creationCompte() {
		String login=saisieString("Login");
		String mail=saisieString("mail");
		String password=saisieString("password");

		Compte c=new Compte(login,mail,password);

		daoCompte.insert(c);
		menuPrincipal();

	}

	private static void listeVoyages() {

		List<Pays> p=daoPays.findAll();
		for(Pays c:p) {
			System.out.println(c);
		}

		System.out.println();
		System.out.println("1-R�server un voyage :");
		System.out.println("2 - Retour au menu principal ");
		int choix = saisieInt("");

		switch(choix)
		{case 1 :

			if(compteConnected instanceof Compte)
			{ choixReservation();

			}

			else if(compteConnected==null) { 
				System.out.println("Veuillez vous connecter pour pouvoir r�server un voyage");
				seConnecter();
			} break;

		case 2 : menuPrincipal();break;}

	}


	private static void choixReservation() {

		for(Voyage v:daoVoyage.findAll()) {
			System.out.println(v);
		}

		int id=saisieInt("Saisir l'id du voyage ");

		Voyage v=daoVoyage.findById(id);

		/*List<Activite> activites=new ArrayList();
				for (Activite a:daoActivite.findByIdPays(v.getDestination().getId()) {
					System.out.println(a);
				}

				int choix=saisieInt("Saisir id de l'activit� ");
				activites.add(daoActivite.findById(choix));

				/*for (Transport t: daoPays.findWithTransport(v.getDestination().getId())) {
				System.out.println(t);				
				}

				String choixTransport=saisieString("Choisir un transport");
		 */

		Reservation r=new Reservation(v,compteConnected);
		id=r.getId();

		System.out.println("Pour valider la r�servation, veuillez rentrer les donn�es suivantes : ");
		String nom=saisieString("Nom : ");
		String prenom=saisieString("Prenom : ");


		Voyageur voy=new Voyageur(id,nom,prenom);
		System.out.println("R�capitulatif r�servation du "+r.getDate());
		System.out.println(v.getDepart().getNom()+" to "+v.getDestination().getNom()+" du "+daoVoyage.findById(v.getId()).getDebut()+" au "+daoVoyage.findById(v.getId()).getFin()+" \n");
		menuPrincipal();
	}



	public static void main(String[] args) {
		menuPrincipal();
	}
}