package metier;

public class Admin extends Compte{
	
	public Admin(int id, String nom, String email, String password) {
		super(id, nom,email, password);
	}

}
