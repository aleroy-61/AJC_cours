package metier;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class Reservation {
	private Voyage idVoyage;
	private Compte client;
	private LocalDate date;
	private double prix;
	private int id;
	
//	private List <Activite> activites = new ArrayList(); 
	
	public int getId() {
		return id;
	}


	public void setId(int id) {
		this.id = id;
	}


	public Reservation() {
	}

	
	public Reservation(Compte client,int id,Voyage idVoyage, String date, double prix) {
		this.client=client;
		this.id=id;
		this.idVoyage = idVoyage;
		this.date = LocalDate.parse(date);
		this.prix = prix;
//		this.activites = activites;
	}


	public Reservation(Voyage idVoyage, String date, double prix) {
		this.idVoyage = idVoyage;
		this.date = LocalDate.parse(date);
		this.prix = prix;
	
	}


	public Reservation(Voyage v, Compte client) {
		this.client=client;
		this.date = LocalDate.now();
		this.prix = 1000;
		
	}

	public Voyage getIdVoyage() {
		return idVoyage;
	}

	public void setIdVoyage(Voyage idVoyage) {
		this.idVoyage = idVoyage;
	}


	public LocalDate getDate() {
		return date;
	}

	public void setDate(LocalDate date) {
		this.date = date;
	}

	public double getPrix() {
		return prix;
	}

	public void setPrix(double prix) {
		this.prix = prix;
	}

	public Compte getClient() {
		return client;
	}

	public double prix() {
        return prix=Pays.getPrixJours()+Transport.getPrix();
    }

	public void setClient(Client client) {
		this.client = client;
	}

//	public List<Activite> getActivites() {
//		return activites;
//	}
//
//
//	public void setActivites(List<Activite> activites) {
//		this.activites = activites;
//	}
	@Override
	public String toString() {
		return "Reservation [idVoyage=" + idVoyage + ", client=" + client + ", date=" + date + ", prix=" + prix
				+ ", id=" + id + "]";
	}


	


	

	


}
