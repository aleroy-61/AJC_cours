package metier;

public class Client extends Compte{
	
	public Client(int id, String nom, String email, String password) {
		super(id, nom,email, password);
	}

}