package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import metier.Pays;
import metier.Reservation;
import metier.Voyage;

public class DAOReservation implements IDAO<Reservation, Integer>{


	public Reservation findById(Integer id) {
		Reservation reservation= null;
		DAOActivite daoActivite=new DAOActivite();
		try {
			Class.forName("com.mysql.jdbc.Driver");

			Connection conn=DriverManager.getConnection(chemin,login,password);
			PreparedStatement ps = conn.prepareStatement("Select * from reservation where id=?");
			ps.setInt(1,id);
			ResultSet rs = ps.executeQuery();

			while(rs.next()) 
			{

				DAOVoyage daoVoyage = new DAOVoyage();
				Voyage idVoyage=daoVoyage.findById(rs.getInt("idVoyage"));

				String date=rs.getString("date");
				String heure=rs.getString("heure");
				double prix=rs.getDouble("prix");
				//				Activite activites=((Activite) rs).getActivites("activites");

				reservation = new Reservation(idVoyage,date,prix);
			}
			rs.close();
			ps.close();
			conn.close();	
		} catch (Exception e) {
			e.printStackTrace();
		}

		return reservation;
	}



	public List<Reservation> findAll() {
		List<Reservation> reservations= new ArrayList();
		try {
			Class.forName("com.mysql.jdbc.Driver");

			Connection conn=DriverManager.getConnection(chemin,login,password);
			PreparedStatement ps = conn.prepareStatement("Select * from reservation");
			ResultSet rs = ps.executeQuery();

			while(rs.next()) 
			{
				
				DAOVoyage daoVoyage = new DAOVoyage();
				Voyage idVoyage=daoVoyage.findById(rs.getInt("idVoyage"));
				String date=rs.getString("date");
				String heure=rs.getString("heure");
				double prix=rs.getDouble("prix");


				Reservation r = new Reservation(idVoyage,date,prix);
				reservations.add(r);
			}
			rs.close();
			ps.close();
			conn.close();	
		} catch (Exception e) {
			e.printStackTrace();
		}

		return reservations;
	}


	public void insert(Reservation r) {
		DAOVoyage daoVoyage = new DAOVoyage();
		try {
			Class.forName("com.mysql.jdbc.Driver");


			Connection conn=DriverManager.getConnection(chemin,login,password);

			PreparedStatement ps = conn.prepareStatement("INSERT INTO reservation (idVoyage,date,prix) VALUES(?,?,?)");
			
			ps.setVoyage(1, r.getIdVoyage());
			ps.setString(2, r.getDate().toString());
			ps.setDouble(3, r.getPrix());


			ps.executeUpdate();

			ps.close();
			conn.close();

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public void update(Reservation r) {
		try {
			Class.forName("com.mysql.jdbc.Driver");


			Connection conn=DriverManager.getConnection(chemin,login,password);

			PreparedStatement ps = conn.prepareStatement("Update reservation set date=?,prix=?, idVoyage=? where id=?");

			
			ps.setString(1, r.getDate().toString());
			ps.setDouble(2, r.getPrix());
			ps.setVoyage(3, r.getIdVoyage());
			ps.setInt(4,r.getId());

			ps.executeUpdate();

			ps.close();
			conn.close();

		} catch (Exception e) {
			e.printStackTrace();
		}
	}


	public void delete(Reservation r) {
		try {
			Class.forName("com.mysql.jdbc.Driver");

			Connection conn=DriverManager.getConnection(chemin,login,password);

			PreparedStatement ps = conn.prepareStatement("DELETE FROM reservation where id=?");
			ps.setInt(1,r.getId());

			ps.executeUpdate();

			ps.close();
			conn.close();

		} catch (Exception e) {
			e.printStackTrace();
		}
	}




}
