package dao;

import java.util.List;

import metier.Admin;

public class DAOAdmin implements IDAO<Admin, Integer>{

	@Override
	public Admin findById(Integer id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Admin> findAll() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void insert(Admin d) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void update(Admin d) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void delete(Admin d) {
		// TODO Auto-generated method stub
		
	}

		
}