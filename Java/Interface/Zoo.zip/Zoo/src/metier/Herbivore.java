package metier;

public interface Herbivore {
 
	
	public void manger(String plante);
	

}
