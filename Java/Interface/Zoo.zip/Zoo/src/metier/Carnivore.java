package metier;

public interface Carnivore {

	
	public void manger(Animal a);
}
