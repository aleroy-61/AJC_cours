package metier;

public abstract class Animal {

}
