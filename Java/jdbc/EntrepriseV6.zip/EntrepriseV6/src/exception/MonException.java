package exception;

public class MonException extends Exception{

	
	public MonException() 
	{
		super("Mon message");
	}
}
