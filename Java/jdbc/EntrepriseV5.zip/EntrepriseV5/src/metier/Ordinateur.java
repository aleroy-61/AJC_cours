package metier;

public class Ordinateur {

	private int numero;
	
	private String marque;
	
	private int ram;

	private String couleur;
	
	
}
