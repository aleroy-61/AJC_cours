package test;

import heritage.A;
import heritage.B;
import heritage.C;

public class TestABC {

	public static void main(String[] args) {
		
		A a = new A(10);
		
		B b = new B(15,"");
		
		C c = new C(10,"");
		
		
		
		c.m1();
		
		
		

	}

}
