package metier;

public class Formateur extends Personne {

	public Formateur(String nom, String prenom, int age) {
		super(nom, prenom, age);
	}

	private String cours;
	
	
	


	
}
