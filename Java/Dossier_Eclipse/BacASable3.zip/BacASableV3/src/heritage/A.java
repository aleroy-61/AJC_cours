package heritage;

public class A {
	
	protected int valeur;

	public A(int valeur) {
		this.valeur = valeur;
	}

	public int getValeur() {
		return valeur;
	}

	public void setValeur(int valeur) {
		this.valeur = valeur;
	}
	
	
	
	
	public void m1() 
	{
		System.out.println("Je suis m1 de A");
	}
	
	
	public void m2() 
	{
		System.out.println("Je suis m2 de A");
	}
	
	
	

}
