package heritage;

public class C extends B{

	public C(int valeur, String chaine) {
		super(valeur, chaine);
	}

}
