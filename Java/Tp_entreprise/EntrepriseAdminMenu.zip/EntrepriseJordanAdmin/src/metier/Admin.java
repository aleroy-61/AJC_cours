package metier;

public class Admin extends Compte {

	
	public Admin(String login,String password) {
		super(login,password);
	}
}
