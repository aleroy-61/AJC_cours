package metier;

public class Secretaire extends Compte {

	public Secretaire(int id, String login, String password) {
		super(id, login, password);
		
	}

}
