package dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import metier.Visite;


public class DAOVisite implements IDAO<Visite, Integer>{

		public Visite findById(Integer id) {
			Visite visite= null;
			try {
				Class.forName("com.mysql.jdbc.Driver");
				
				Connection conn=DriverManager.getConnection(chemin,login,password);
				PreparedStatement ps = conn.prepareStatement("Select * from visite where id=?");
				ps.setInt(1,id);
				ResultSet rs = ps.executeQuery();
				
				while(rs.next()) 
				{
					int id1=rs.getInt("id");
					int idPatient=rs.getInt("idPatient");
					int idCptMed=rs.getInt("idCptMed");
					double coutConsultation=rs.getInt("coutConsultation");
					int salle=rs.getInt("salle");
					LocalDate date= rs.getLocalDate("date");
					
					
				 visite = new Visite(id1,idPatient,idCptMed,coutConsultation,salle,date);
				}
				rs.close();
				ps.close();
				conn.close();	
			} catch (Exception e) {
				e.printStackTrace();
			}
			
			return visite;
		}

		
		
		public List<Visite> findAll() {
			List<Visite> visites= new ArrayList();
			try {
				Class.forName("com.mysql.jdbc.Driver");
				
				Connection conn=DriverManager.getConnection(chemin,login,password);
				PreparedStatement ps = conn.prepareStatement("Select * from visite");
				ResultSet rs = ps.executeQuery();
				
				while(rs.next()) 
				{
					int id=rs.getInt("id");
					int idPatient=rs.getInt("idPatient");
					int idCptMed=rs.getInt("idCptMed");
					double coutConsultation=rs.getInt("coutConsultation");
					int salle=rs.getInt("salle");
					LocalDate date= rs.getLocalDate.parse("date");
					
					Visite visite = new Visite(id,idPatient,idCptMed,coutConsultation,salle,date);
					visites.add(visite);
				}
				rs.close();
				ps.close();
				conn.close();	
			} catch (Exception e) {
				e.printStackTrace();
			}
			
			return visites;
		}

		
		
		public void insert(Visite v) {
			try {
				Class.forName("com.mysql.jdbc.Driver");
				
				
				Connection conn=DriverManager.getConnection(chemin,login,password);
				
				PreparedStatement ps = conn.prepareStatement("INSERT INTO visite (id,idPatient,idCptMed,coutConsultation,salle,date)  VALUES(?,?,?,?,?,?)");
				ps.setInt(1, v.getId());
				ps.setInt(2, v.getIdPatient());
				ps.setInt(3, v.getIdCptMed());
				ps.setDouble(4, v.getCoutConsultation());
				ps.setInt(5, v.getSalle());
				ps.setLocalDate(6, v.getDate());
				
				ps.executeUpdate();
		
				ps.close();
				conn.close();

			} catch (Exception e) {
				e.printStackTrace();
			}
			
		}

		public void update(Visite v) {
			try {
				Class.forName("com.mysql.jdbc.Driver");
				
				
				Connection conn=DriverManager.getConnection(chemin,login,password);
				
				PreparedStatement ps = conn.prepareStatement("Update visite set id=?,idPatient=?,idCptMed=?,coutConsultation=?,salle=?,date=? where id=?");
				
				ps.setInt(1, v.getId());
				ps.setInt(2, v.getIdPatient());
				ps.setInt(3, v.getIdCptMed());
				ps.setDouble(4, v.getCoutConsultation());
				ps.setInt(5, v.getSalle());
				ps.setLocalDate(6, v.getDate());
			
				ps.executeUpdate();
		
				ps.close();
				conn.close();

			} catch (Exception e) {
				e.printStackTrace();
			}
		}

		public void delete(Visite v) {
			try {
				Class.forName("com.mysql.jdbc.Driver");
				
				Connection conn=DriverManager.getConnection(chemin,login,password);
				
				PreparedStatement ps = conn.prepareStatement("DELETE FROM visite where idPatient=?");
				ps.setInt(1,v.getId());
			
				ps.executeUpdate();
		
				ps.close();
				conn.close();

			} catch (Exception e) {
				e.printStackTrace();
			}
		}

	

}


