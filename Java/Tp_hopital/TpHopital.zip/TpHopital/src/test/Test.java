package test;

import java.time.LocalDate;
import java.util.List;
import java.util.Scanner;

import dao.DAOCompte;
import dao.DAOPatient;
import dao.DAOVisite;
import metier.Compte;
import metier.Patient;
import metier.Visite;

public class Test {


	public static String saisieString(String message) 
	{
		Scanner sc = new Scanner(System.in);
		System.out.println(message);
		return sc.nextLine();
	}

	public static double saisieDouble(String message) 
	{
		Scanner sc = new Scanner(System.in);
		System.out.println(message);
		return sc.nextDouble();
	}

	public static int saisieInt(String message) 
	{
		Scanner sc = new Scanner(System.in);
		System.out.println(message);
		return sc.nextInt();
	}
	static DAOCompte daoCompte= new DAOCompte();
	static DAOPatient daoPatient= new DAOPatient();
	static DAOVisite daoVisite= new DAOVisite();
	static Compte compteConnected;

	private static void menuPrincipal() {

		compteConnected = null;
		System.out.println("Welcome, merci de faire un choix :");
		System.out.println("1 - Se connecter en tant que m�decin");
		System.out.println("2 - Se connecter en tant que secr�taire");
		System.out.println("3 - Fermer l'appli");
		int choix = saisieInt("");

		switch(choix) 
		{
		case 1 : seConnecterMedecin();break;
		case 2 : seConnecterSecretaire();break;
		case 3 : System.exit(0);break;
		default : System.out.println("Choix impossible !\n");
		}

		menuPrincipal();

	}

	private static void seConnecterSecretaire() {

		System.out.println("Menu secretaire, merci de faire un choix :");
		System.out.println("1 - Ajouter un patient � la file d'attente");
		System.out.println("2 - Afficher l'�tat de la file d'attente");
		System.out.println("3 - Partir en pause");
		System.out.println("4 - Se deconnecter");
		int choix = saisieInt("");

		switch(choix) 
		{
		case 1 : ajoutPatient();break;
		case 2 : listePatient();break;
		case 3 : pause();break;
		case 4 : menuPrincipal();
		default : System.out.println("Choix impossible !\n");
		}

		menuPrincipal();

	}


	private static void pause() {
		

	}

	private static void listePatient() {
		List<Patient> patient = daoPatient.findAll();

		for(Patient p : patient)
		{
			System.out.println(p);
		}

	}

	private static void ajoutPatient() {

		int id = saisieInt("Saisir id patient");
		String nom=saisieString("Saisir nom patient");
		String prenom=saisieString("Saisir prenom patient");

		Patient p = new Patient(id,nom,prenom);
		daoPatient.insert(p);

	}

	private static void seConnecterMedecin() {

		System.out.println("Menu medecin, merci de faire un choix :");
		System.out.println("1 - Visualiser le liste d'attente et le prochain patient");
		System.out.println("2 - Appel du patient suivant");
		System.out.println("3 - Sauvegarder la liste de mes visites");
		System.out.println("4 - Se deconnecter");
		int choix = saisieInt("");

		switch(choix) 
		{
		case 1 : listePatient();break;
		case 2 : appelPatient();break;
		case 3 : sauvegardeVisites();break;
		case 4 : menuPrincipal();
		default : System.out.println("Choix impossible !\n");
		}

		menuPrincipal();

	}

	private static void sauvegardeVisites() {
		int id = saisieInt("Saisir id visite");
		int idPatient = saisieInt("Saisir id patient");
		int idCptMed = saisieInt("Saisir id medecin");
		double coutConsultation=saisieDouble("Saisir cout de la consultation");
		int salle = saisieInt("Saisir le numero de la salle");
		LocalDate date = null;

		Visite v = new Visite(id,idPatient,idCptMed,coutConsultation,salle,date);
		daoVisite.insert(v);

	}

	private static Patient appelPatient() {
		System.out.println("Fin de la consultation");
		System.out.println("Patient suivant");
		List<Patient> patient=daoPatient.findAll();
		
		for(int i=0;i<patient.size();i++) 
		{
			Patient e = patient.get(i);
			System.out.println(i+"- "+e.getNom()+"("+e.getId()+")");
		}
		
		int choix = saisieInt("");
		Patient p = patient.get(choix);
		return p;


	
}
}
