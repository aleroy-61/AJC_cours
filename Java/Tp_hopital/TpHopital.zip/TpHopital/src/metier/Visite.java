package metier;

import java.sql.Date;
import java.time.LocalDate;

public class Visite {

	private int id;
	private int idPatient;
	private int idCptMed;
	private double coutConsultation;
	private int salle;
	private LocalDate date;
	
	public Visite(int id, int idPatient, int idCptMed, double coutConsultation, int salle, LocalDate date) {
		this.id = id;
		this.idPatient = idPatient;
		this.idCptMed = idCptMed;
		this.coutConsultation = coutConsultation;
		this.salle = salle;
		this.date = date;
	}
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getIdPatient() {
		return idPatient;
	}
	public void setIdPatient(int idPatient) {
		this.idPatient = idPatient;
	}
	public int getIdCptMed() {
		return idCptMed;
	}
	public void setIdCptMed(int idCptMed) {
		this.idCptMed = idCptMed;
	}
	public double getCoutConsultation() {
		return coutConsultation;
	}
	public void setCoutConsultation(double coutConsultation) {
		this.coutConsultation = coutConsultation;
	}
	public int getSalle() {
		return salle;
	}
	public void setSalle(int salle) {
		this.salle = salle;
	}
	public LocalDate getDate() {
		return date;
	}
	public void setDate(LocalDate date) {
		this.date = date;
	}
	@Override
	public String toString() {
		return "Visite [id=" + id + ", idPatient=" + idPatient + ", idCptMed=" + idCptMed + ", coutConsultation="
				+ coutConsultation + ", salle=" + salle + ", date=" + date + "]";
	}
	
	
	
}
