package metier;

public class Medecin extends Compte{
	
	int salle;
	public Medecin(int id, String login, String password) {
		super(id, login, password);
		
	}
	public int getSalle() {
		return salle;
	}
	public void setSalle(int salle) {
		this.salle = salle;
	}

	

}
